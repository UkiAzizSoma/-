package com.CityHeros.ABCD_FragOfMenu;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.CityHeros.ABCDE_FragsOfMenuBN.NB_Books;
import com.CityHeros.ABCDE_FragsOfMenuBN.NB_Fame;
import com.CityHeros.ABCDE_FragsOfMenuBN.NB_WorldRec;
import com.CityHeros.firstProject.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class FragThree extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view =   inflater.inflate(R.layout.nb_controler, container , false );



        BottomNavigationView navigationView = view.findViewById(R.id.nav_view);
        navigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.books:
                        getChildFragmentManager().beginTransaction().replace(R.id.nav_host_fragment ,new NB_Books()).commit();

                        break;
                    case R.id.fame:
                        getChildFragmentManager().beginTransaction().replace(R.id.nav_host_fragment ,new NB_Fame()).commit();

                        break;
                    case R.id.rec:
                        getChildFragmentManager().beginTransaction().replace(R.id.nav_host_fragment ,new NB_WorldRec()).commit();

                        break;
                }

                return true;
            }
        });



        return view;
    }
}
