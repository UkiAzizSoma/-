package com.CityHeros.ABCDE_FragsOfMenuBN;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MenuItem;

import com.CityHeros.firstProject.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class BN_C extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.nb_controler);


        BottomNavigationView navigationView = findViewById(R.id.nav_view);


        navigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.books:
                        getSupportFragmentManager().beginTransaction().replace(R.id.nav_host_fragment ,new NB_Books()).commit();
                        getSupportActionBar().setTitle(getResources().getString(R.string.nb_books));

                        break;
                    case R.id.fame:
                        getSupportFragmentManager().beginTransaction().replace(R.id.nav_host_fragment ,new NB_Fame()).commit();
                        getSupportActionBar().setTitle(getResources().getString(R.string.nb_fame));
                        break;
                    case R.id.rec:
                        getSupportFragmentManager().beginTransaction().replace(R.id.nav_host_fragment ,new NB_WorldRec()).commit();
                        getSupportActionBar().setTitle(getResources().getString(R.string.nb_rec));
                        break;
                }

                return true;
            }
        });

    }
}
