package com.CityHeros.ABC_Register;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.CityHeros.firstProject.R;

public class Rejester_asAdmin extends AppCompatActivity {

    private String TYPE_OF_USER ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.d_rejester_as_admin);




        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("انشاء حساب");








    }
    //button event

    public void toRP(View view){

            Intent toRejester_page = new Intent(this, Rejester_Page.class);
            toRejester_page.putExtra("TYPE_OF_USER",TYPE_OF_USER);
            toRejester_page.putExtra("imageKey",R.drawable.ic_manger);

            startActivity(toRejester_page);


    }








}
