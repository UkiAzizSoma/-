package com.CityHeros.ABCDE_FragsOfMenuBN;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.CityHeros.firstProject.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class NB_WorldRec extends Fragment {

     private RecyclerView recyclerView ;
     private NB_WorldAdapter  adapter ;
     private List<NB_WorldModel> nb_worldModels ;

     private DatabaseReference myRef;
     private ProgressBar progressBar;




    public NB_WorldRec() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             final Bundle savedInstanceState) {




        //Firebase Database
        myRef = FirebaseDatabase.getInstance().getReference("uploadsAdmin");

        //Floating ActionBar


        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.nb__world_rec, container, false);

        FloatingActionButton floatingActionButton = view.findViewById(R.id.floatingActionButton);
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openFileChooser();
            }
        });

        progressBar = view.findViewById(R.id.progressBar4);
        recyclerView = view.findViewById(R.id.recyclerWorld);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        nb_worldModels = new ArrayList<>();

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot snapshot1 : snapshot.getChildren()){
                    NB_WorldModel a = snapshot1.getValue(NB_WorldModel.class);
                    nb_worldModels.add(a);

                }

                adapter = new NB_WorldAdapter(getContext(),nb_worldModels);
                recyclerView.setAdapter(adapter);
                progressBar.setVisibility(View.INVISIBLE);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(getContext(),error.getMessage(),Toast.LENGTH_SHORT).show();
                progressBar.setVisibility(View.INVISIBLE);
            }
        });









        return view;
    }

    private void openFileChooser() {
        Intent intent = new Intent(getContext(),NB_Uplaod_Admin.class);
        startActivity(intent);
    }
}
