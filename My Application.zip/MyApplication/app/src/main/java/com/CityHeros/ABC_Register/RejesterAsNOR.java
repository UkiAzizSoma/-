package com.CityHeros.ABC_Register;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.CityHeros.firstProject.R;

public class RejesterAsNOR extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.d_rejester_as_n_o_r);

        //Action bar
      getSupportActionBar().setDisplayHomeAsUpEnabled(true);
      getSupportActionBar().setTitle("انشاء حساب");
    }






    //intent to admin page
    public void toAdminClick(View view) {
        Intent toAdmin = new Intent(this, Rejester_asAdmin.class);
        startActivity(toAdmin);
    }




    //to Rejester page
    public void toRP1(View view) {

        Intent toRejester = new Intent(this, Rejester_Page.class);

        startActivity(toRejester);

    }





}
