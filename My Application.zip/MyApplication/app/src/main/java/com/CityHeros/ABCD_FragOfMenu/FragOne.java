package com.CityHeros.ABCD_FragOfMenu;



import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;


import com.CityHeros.ABC_Register.UserInformation;
import com.CityHeros.firstProject.R;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class FragOne extends Fragment {

    private TextView name,email,password,age,city;
    private DatabaseReference reference ;




    @Nullable
    @Override
    public View onCreateView(@NonNull final LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {





        View lay = inflater.inflate(R.layout.c_1_frag, container, false);
        ImageView imageView = lay.findViewById(R.id.imageFew);
        name = lay.findViewById(R.id.name);
        email = lay.findViewById(R.id.email);
        password = lay.findViewById(R.id.pass_wordss);
        age = lay.findViewById(R.id.age);
        city = lay.findViewById(R.id.city);
        reference = FirebaseDatabase.getInstance().getReference("users");







        return lay;


    }

    @Override
    public void onStart() {
        super.onStart();
        GoogleSignInAccount googleSignInAccount = GoogleSignIn.getLastSignedInAccount(getContext());
        if (googleSignInAccount != null) {
            name.setText(googleSignInAccount.getDisplayName());
            email.setText(googleSignInAccount.getEmail());
            password.setText("لايوجد");
            age.setText("لايوجد");
            city.setText("لايوجد");
        }else{
            reference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {



                    for (DataSnapshot ds:dataSnapshot.getChildren()){
                        UserInformation information = ds.getValue(UserInformation.class);

                        if (information != null) {
                            name.setText(information.getName());
                            email.setText(information.getEmail());
                            password.setText(information.getPass());
                            age.setText(information.getAge());
                            city.setText(information.getCity());
                        }


                    }

                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    // Failed to read value
                }
            });


        }


    }
}


