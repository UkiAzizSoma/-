package com.CityHeros.A_CodeForIraq;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.CityHeros.firstProject.R;

public class B_Introduction extends AppCompatActivity {







    int i;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.b_introduction);

        getSupportActionBar().setTitle("فكرة سريعة");


         //connection
            Bundle bundle = getIntent().getExtras();
            if (bundle != null){
                i = bundle.getInt("TYPE_OF_USER");

            }








    }






    public void toSucka(View view){



                Intent toSucka = new Intent(this, B_Sucka.class);

                toSucka.putExtra("TYPE_OF_USER",i);

                startActivity(toSucka);

        }



    }











