package com.CityHeros.A_CodeForIraq;



import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;

import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;

import android.widget.Toast;

import com.CityHeros.AB_Beginning.A_Login_form;
import com.CityHeros.ABCD_FragOfMenu.FragFive;
import com.CityHeros.ABCD_FragOfMenu.FragFour;
import com.CityHeros.ABCD_FragOfMenu.FragOne;
import com.CityHeros.ABCD_FragOfMenu.FragSeven;
import com.CityHeros.ABCD_FragOfMenu.FragSix;
import com.CityHeros.ABCD_FragOfMenu.FragThree;
import com.CityHeros.ABCD_FragOfMenu.FragVideos;
import com.CityHeros.firstProject.R;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;

public class B_Sucka extends AppCompatActivity  implements NavigationView.OnNavigationItemSelectedListener {

    DrawerLayout drawerLayout;
    NavigationView navigationView ;
    Toolbar toolbar;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.b_sucka);
        drawerLayout = findViewById(R.id.drawer_lay3ot);


      toolbar = findViewById(R.id.tool_bar);

        setSupportActionBar(toolbar);

        //bundle

        Bundle bundle  = getIntent().getExtras();
        if (bundle != null){
            int i = bundle.getInt("TYPE_OF_USER");

            LayoutInflater inflater = getLayoutInflater();



        }




        //ActionBarDrawerToggle var = new Ac...(this,drawerlayout,toolbar,@string1,@string2)

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout , toolbar ,R.string.toggle1 , R.string.toggle2);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();




        //draw.. .addDrawerListener(toggle);
        //toggle.syncState();
        navigationView = findViewById(R.id.nav_view);
           navigationView.setNavigationItemSelectedListener(this);

        if (savedInstanceState == null){
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment, new FragVideos()).commit();
            navigationView.setCheckedItem(R.id.videos);
        }


        drawerLayout.isDrawerOpen(GravityCompat.START);




    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
       switch (menuItem.getItemId()){

            case R.id.videos:
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment, new FragVideos()).commit();
            toolbar.setTitle(R.string.frag_videos);
            break;



           case R.id.study:
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment,new FragSeven()).commit();
            toolbar.setTitle(R.string.frag_study);
            break;

           case R.id.lab:
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment,new FragThree()).commit();
            toolbar.setTitle(R.string.lab_section);
            break;

           case R.id.account:
               getSupportFragmentManager().beginTransaction().replace(R.id.fragment,new FragOne()).commit();
               toolbar.setTitle(R.string.Account);
               break;

           case R.id.request:
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment,new FragFour()).commit();
            toolbar.setTitle(R.string.request);
            break;

           case R.id.about:
           getSupportFragmentManager().beginTransaction().replace(R.id.fragment,new FragFive()).commit();
               toolbar.setTitle(R.string.about);
           break;

           case R.id.team:
           getSupportFragmentManager().beginTransaction().replace(R.id.fragment,new FragSix()).commit();
           toolbar.setTitle(R.string.team);
           break;

           case R.id.signout:
              FirebaseAuth.getInstance().signOut();
               finish();
               Intent intent = new Intent( getApplicationContext(), A_Login_form.class);
               startActivity(intent);
               Toast.makeText(getApplicationContext(),R.string.logout,Toast.LENGTH_SHORT).show();

               break;

       }
       //
        // drawerLayout.closeDrawer(GravityCompat.START);
        return true;

    }


}

