package com.CityHeros.ABCDE_FragsOfMenuBN;

import com.CityHeros.firstProject.R;

public class NB_WorldModel {

    private String name;
    private String mImage;

    public NB_WorldModel() {
    }

    public NB_WorldModel(String name, String mImage) {
        if (name.trim().equals("")){
            name = "لا يوجد اسم";
        }
        this.name = name;
        this.mImage = mImage;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getmImage() {
        return mImage;
    }

    public void setmImage(String mImage) {
        this.mImage = mImage;
    }
}
